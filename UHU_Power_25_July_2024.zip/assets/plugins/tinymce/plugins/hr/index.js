// Exports the "hr" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/hr')
//   ES2015:
//     import 'tinymce/plugins/hr'
require('./plugin.js');