<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service_quote extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('Service_quote_model','SQM');
        $this->load->model('Service_model','Ser_M');
        $this->load->model('Supplier_model','SM');
        $this->load->model('Product_model','PM');
        $this->load->model('Complaint_model','CM');
        $this->load->library('User_Utility');
       
    }
	public function index(){
		$this->user_utility->check_login();
		$this->user_utility->check_permission(94);
		$input_data = $this->input->post('dates');
		if (isset($input_data) && !empty($input_data) && $input_data != '') {
			$data['date'] = $input_data;
			$temp = explode('-',$input_data);
			$start_date = date('Y/m/d`',strtotime($temp[0]));
			$end_date = date('Y/m/d',strtotime($temp[1]));
			// echo 'with date';	
		}else{
			$current_date = date('m/d/Y');
			$one_week = date('m/d/Y', strtotime('-1 week', strtotime($current_date)));
			$data['date'] = $one_week . ' - ' . $current_date;
			$start_date = date('Y/m/d',strtotime($one_week));
    		$end_date = date('Y/m/d',strtotime($current_date));
		}
		// $data['service_quotes'] = $this->NM->Get_service_quotes($start_date,$end_date);
		$this->load->view('service_quote/service_quotes',$data);
	}

	public function add_service_quote(){
		$this->user_utility->check_login();
		$this->user_utility->check_permission(95);

		$data['suppliers'] = $this->SM->Get_all_supplier();
		$data['services'] = $this->Ser_M->Get_services();
		$data['products'] = $this->PM->Get_all_products();
		$data['complaints'] = $this->CM->Get_unassigned_complaints();
		$data['product_cats'] = $this->PM->Get_all_product_cat();

		$this->load->view('service_quote/add_service_quote', $data);
	}

	public function adding_service_quote(){
		$this->user_utility->check_login();
		$this->user_utility->check_permission(95);

		$data = $this->input->post();

		$service_quote['sup_cus_id'] = $data['supplier_id'];
		$service_quote['date'] = $data['date'];
		
		$service_quote_details['service_quote_id'] 			= $this->SQM->Insert_service_quote($service_quote);
		$service_quote_details['complaint_id'] 				= $data['complaint_id'];
		$service_quote_details['company_id'] 				= $data['company_id'];
		$service_quote_details['subject'] 					= $data['subject'];
		$service_quote_details['first_line_description'] 	= $data['first_line_description'];
		$service_quote_details['payment_line'] 				= $data['payment_line'];
		$service_quote_details['work_completion_line'] 		= $data['work_completion_line'];
		$service_quote_details['offer_subject_line']		= $data['offer_subject_line'];
		$service_quote_details['last_line'] 				= $data['last_line'];

		$this->SQM->Insert_service_quote_details($service_quote_details);

		$service_quote_product['service_quote_id'] = $service_quote_details['service_quote_id'];
		foreach ($data['products'] as $product) {
			$service_quote_product['product_id'] 	= $product['product_id'];
			$service_quote_product['qty'] 			= $product['product_qty'];
			$service_quote_product['cost'] 			= $product['product_cost'];
			$service_quote_product['tax'] 			= $product['product_tax'];
		}

		$this->SQM->Insert_service_quote_products($service_quote_product);

		$service_quote_service['service_quote_id'] = $service_quote_details['service_quote_id'];
		foreach ($data['service'] as $service) {
			$service_quote_service['render_service_id'] 	= $service['service_id'];
			$service_quote_service['cost'] 			= $service['service_cost'];
			$service_quote_service['tax'] 			= $service['service_tax'];
		}

		$this->SQM->Insert_service_quote_service($service_quote_service);

		$this->session->set_flashdata('add', 'add');
		redirect('service_quote/add_service_quote');

	}
	
}
