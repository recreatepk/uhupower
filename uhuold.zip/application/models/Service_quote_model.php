<?
class Service_quote_model extends CI_Model {

	public function Get_service_quote($start_date,$end_date){
		return $this->db->where('add_date >=',$start_date)
						->where('add_date <=',$end_date)
						->get('service_quote')->result_array();
	}

	public function Insert_service_quote($service_quote){
		$this->db->insert('service_quote', $service_quote);
		return $this->db->insert_id();
	}
	public function Insert_service_quote_details($service_quote_details){
		$this->db->insert('service_quote_details', $service_quote_details);
	}
	public function Insert_service_quote_products($service_quote_product){
		$this->db->insert('service_quote_product', $service_quote_product);
	}
	public function Insert_service_quote_service($service_quote_service){
		$this->db->insert('service_quote_service', $service_quote_service);
	}
	

}