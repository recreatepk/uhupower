<!-- jQuery  -->
        <script src="<?=base_url()?>assets/js/jquery.min.js"></script>
        <script src="<?=base_url()?>assets/js/bootstrap.bundle.min.js"></script>
        <script src="<?=base_url()?>assets/js/metismenu.min.js"></script>
        <script src="<?=base_url()?>assets/js/waves.js"></script>
        <script src="<?=base_url()?>assets/js/feather.min.js"></script>
        <script src="<?=base_url()?>assets/js/simplebar.min.js"></script>
        <script src="<?=base_url()?>assets/js/jquery-ui.min.js"></script>
        <script src="<?=base_url()?>assets/js/moment.js"></script>
        <script src="<?=base_url()?>assets/plugins/daterangepicker/daterangepicker.js"></script>

         <!-- Sweet-Alert  -->
        <script src="<?=base_url()?>assets/plugins/sweet-alert2/sweetalert2.min.js"></script>
        <script src="<?=base_url()?>assets/pages/jquery.sweet-alert.init.js"></script>

        <script src="<?=base_url()?>assets/plugins/select2/select2.min.js"></script>
        <!-- color picker -->
        <script src="<?=base_url()?>assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
        
        <!-- test -->

        <script src="<?=base_url()?>assets/plugins/timepicker/bootstrap-material-datetimepicker.js"></script>
        <!-- max lenght -->
        <script src="<?=base_url()?>assets/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>

        <!-- advance forms -->
        <script src="<?=base_url()?>assets/pages/jquery.forms-advanced.js"></script>

        <!-- App js -->
        <script src="<?=base_url()?>assets/js/app.js"></script>
        <script>
  // Use JavaScript to scroll to the corresponding <a> element in the sidebar
  document.addEventListener("DOMContentLoaded", function() {
    var linkToScroll = document.getElementById(currentPage);
    if (linkToScroll) {
      linkToScroll.scrollIntoView({ behavior: "smooth" }); // Smooth scroll to the link
    }
  });
</script>
