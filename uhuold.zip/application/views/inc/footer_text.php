 <footer class="footer text-center text-sm-left">
                    &copy; <?=date('Y')?> UHU ERP <span class="d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i> by <a href="https://recreatepk.com" target="_blank">Re | Create Technologies</a></span>
                </footer><!--end footer-->